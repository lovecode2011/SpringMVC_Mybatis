package info.wwhaha.mybatis.mbg.service;

import info.wwhaha.mybatis.mbg.model.User;

public interface IUserService {  
    public User getUserById(int userId);  
} 
